
0.3.1 / 2010-06-28
==================

  * Faster assert.response()

0.3.0 / 2010-06-28
==================

  * Added -p, --port NUM flags
  * Added assert.response(). Closes #11

0.2.1 / 2010-06-25
==================

  * Fixed issue with reporting object assertions

0.2.0 / 2010-06-21
==================

  * Added `make uninstall`
  * Added better readdir() failure message
  * Fixed `make install` for kiwi

0.1.0 / 2010-06-15
==================

  * Added better usage docs via --help
  * Added better conditional color support
  * Added pre exit assertion support

0.0.3 / 2010-06-02
==================

  * Added more room for filenames in test coverage
  * Added boring output support via --boring (suppress colored output)
  * Fixed async failure exit status

0.0.2 / 2010-05-30
==================

  * Fixed exit status for CI support

0.0.1 / 2010-05-30
==================

  * Initial release